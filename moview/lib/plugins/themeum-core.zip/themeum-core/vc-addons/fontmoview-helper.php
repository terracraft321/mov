<?php
if ( ! function_exists( 'getMoviewIconsList' ) ) {

	function getMoviewIconsList(){
		return array(
		'Select',
		'moviewclose',
		'moviewstar-blank',
		'moviewstar',
		'moviewspinner',
		'moviewlink',
		'moviewpinterest',
		'moviewyoutube',
		'moviewvimeo',
		'moviewgoogle',
		'moviewinstagram',
		'moviewtwitter',
		'moviewfacebook',
		'moviewglobe',
		'moviewcamera',
		'moviewuser-review',
		'moviewpencil',
		'moviewuser',
		'moviewtop-list',
		'moviewticket',
		'moviewpopcorn',
		'moviewsearch',
		'moviewstar-line',
		'moviewplay',
		'moviewmail',
		'moviewcup',
		'moviewvideocam',
		'moviewmegaphone',
		'moviewlike',
		'moviewbulb',
		'moviewbook',
		'moview3d-glass',
		'moviewfilm',
		'moviewenter',
		'moviewclock',
		'moviewchair',
		'moviewangle-double-right',
		'moviewangle-double-left',
		'moviewdown',
		'moviewup',
		'moviewangle-right',
		'moviewangle-left'
		);

	}
}